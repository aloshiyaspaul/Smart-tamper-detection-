# Smart Tamper Detection System

An open-source ESP32 prototype for detecting possible weight shortfalls during goods distribution. The prototype reads an expected weight from the Serial Monitor and a simulated measured weight from a potentiometer. It reports **PASS** when the measured value is equal to or greater than the expected value, and **TAMPER ALERT** when it is lower.

> **Prototype note:** A potentiometer is used only to simulate a weighing input in a simulator such as Wokwi. For real measurements, connect a suitable load cell through an HX711 amplifier and calibrate it. This prototype is an educational demonstration, not a certified weighing instrument.

## Features
- ESP32-based decision logic
- Expected weight entered through Serial Monitor
- Simulated actual weight from an analog input
- LED and buzzer alert outputs
- One decision per run; reset/restart to perform another test
- Sample test cases and architecture documentation

## Hardware
- ESP32 development board
- Potentiometer (simulation input)
- LED and suitable series resistor (optional)
- Active buzzer (optional; use a transistor driver if required by your buzzer's current)
- Jumper wires and breadboard

## Wiring (ESP32)
| Part | ESP32 connection |
|---|---|
| Potentiometer outer pin 1 | 3V3 |
| Potentiometer outer pin 2 | GND |
| Potentiometer middle/wiper | GPIO 34 |
| LED anode | GPIO 2 through a suitable resistor |
| LED cathode | GND |
| Buzzer signal | GPIO 15 (use a suitable driver if needed) |
| Buzzer GND | GND |

Do not connect a 5 V signal to an ESP32 GPIO. Pin availability can vary by board.

## Setup
1. Install the Arduino IDE: https://www.arduino.cc/en/software
2. Install ESP32 board support using the official Espressif Arduino core instructions: https://docs.espressif.com/projects/arduino-esp32/en/latest/installing.html
3. Connect the ESP32 by USB and select the correct board and port.
4. Open `src/smart_tamper.ino`.
5. Upload the sketch.
6. Open Serial Monitor and set baud rate to **115200**.
7. Enter an expected weight in grams (for example, `500`) and press Enter.
8. Adjust the potentiometer to simulate the measured weight. The sketch converts its ADC reading to a demonstration range of 0–1000 g, then makes one decision and stops.

## Decision rule
- `actualWeight >= expectedWeight` → **PASS**
- `actualWeight < expectedWeight` → **TAMPER ALERT**

This intentionally rejects 499 g when the expected value is 500 g, while accepting 500 g or 510 g. The potentiometer-to-weight conversion is only a simulation mapping; it is not a calibrated scale.

## Environment variables
No environment variables are required. The firmware runs on the ESP32 and uses compile-time pin constants. If you later add a cloud dashboard or API, store credentials outside source control and document them here; never commit real secrets.

## Repository contents
- `src/` — ESP32 Arduino firmware
- `docs/technical-design.md` — architecture and technical design
- `diagrams/system_architecture.png` — architecture diagram
- `data/sample_data.csv` — sample input/output cases
- `tests/test_cases.md` — manual and logic test cases
- `LICENSE` — MIT License

## Simulation
You can reproduce the circuit in Wokwi: https://wokwi.com/ . Create an ESP32 project, add the potentiometer, LED, and buzzer, wire them according to the table, and paste the sketch into the project. Wokwi components and exact buzzer behavior can differ by simulator configuration.

## Limitations and next steps
- Potentiometer input is a simulated weight, not a real measurement.
- Add a load cell + HX711 module and perform calibration before hardware trials.
- Add a timestamped event log and authenticated dashboard for deployment.
- Validate sensor accuracy and electrical safety before using in a real shop.
- This prototype detects a weight shortfall; it cannot by itself prove intent or identify who caused it.

## License
Released under the MIT License. See `LICENSE`.
