# Technical Design Document

## 1. Purpose
The Smart Tamper Detection System is an educational IoT prototype intended to demonstrate how a weight shortfall can be flagged during goods distribution. The current simulator uses a potentiometer as a stand-in for a weighing sensor.

## 2. Architecture

```text
Operator enters expected weight
             |
             v
       ESP32 controller <---- Potentiometer / simulated weight
             |
       Compare expected
       and measured weight
             |
       +-----+------+
       |            |
 measured >=     measured <
 expected        expected
       |            |
      PASS       TAMPER ALERT
       |            |
   LED on       Buzzer on
```

See `../diagrams/system_architecture.png` for a rendered diagram.

## 3. Hardware design
- **ESP32:** reads the analog input, accepts expected weight over serial, and applies the decision rule.
- **Potentiometer:** simulator-only analog input mapped to 0–1000 g for demonstration.
- **LED:** indicates PASS.
- **Buzzer:** indicates a low-weight alert.

For a real prototype, replace the potentiometer with a load cell and HX711 load-cell amplifier. The firmware must be adapted to read calibrated mass values from the HX711 library.

## 4. Firmware workflow
1. Initialize Serial Monitor and output pins.
2. Read expected weight from the serial input.
3. Validate that the entered number is greater than zero.
4. Read the analog input and map ADC counts to the simulation range.
5. Compare actual and expected weight.
6. Turn on the LED for PASS, or buzzer for TAMPER ALERT.
7. Stop processing until the board is reset.

## 5. Decision logic
Let `E` be expected weight and `A` be measured weight:
- If `A >= E`, report PASS.
- If `A < E`, report TAMPER ALERT.

Example: E = 500 g, A = 499 g → alert; A = 500 g → pass; A = 510 g → pass.

## 6. Data and interfaces
- Input interface: Serial Monitor, 115200 baud, numeric grams.
- Sensor interface: ESP32 ADC on GPIO 34.
- Output interfaces: GPIO 2 LED and GPIO 15 buzzer.
- Network/dashboard: not implemented in this starter repository; no Wi-Fi credentials or environment variables are needed.

## 7. Testing
Manual test cases are in `../tests/test_cases.md`, with representative data in `../data/sample_data.csv`. Because the simulator maps potentiometer voltage to a value, tests should focus on values produced by the ADC mapping rather than assuming a particular knob angle equals an exact gram value.

## 8. Security, safety, and limitations
- Do not commit Wi-Fi passwords, API keys, or personal data.
- Use a driver transistor when the buzzer exceeds safe GPIO current limits.
- Do not use this prototype as a certified commercial weighing device.
- A low reading is an anomaly indicator and does not prove deliberate fraud.
- For deployment, add sensor calibration, enclosure/tamper-resistant mounting, reliable connectivity, authentication, logging, and field validation.
