/*
  Smart Tamper Detection System — ESP32 prototype
  Input: potentiometer on GPIO 34 (simulation only)
  Outputs: LED on GPIO 2 and buzzer on GPIO 15

  Decision rule:
    measured >= expected -> PASS
    measured < expected  -> TAMPER ALERT

  The potentiometer mapping is not a calibrated weighing instrument.
*/

const int POT_PIN = 34;
const int LED_PIN = 2;
const int BUZZER_PIN = 15;
const float SIMULATED_MAX_GRAMS = 1000.0f;

float expectedWeight = 0.0f;
bool decisionMade = false;

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);

  Serial.println();
  Serial.println("=== Smart Tamper Detection System ===");
  Serial.println("Enter expected weight in grams, then press Enter:");
}

void loop() {
  if (decisionMade) {
    return;  // One decision per run; reset the board for another test.
  }

  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');
    input.trim();
    if (input.length() == 0) return;

    char *endPtr = nullptr;
    expectedWeight = strtof(input.c_str(), &endPtr);
    if (endPtr == input.c_str() || expectedWeight <= 0.0f) {
      Serial.println("Invalid input. Enter a number greater than 0, e.g. 500.");
      Serial.println("Enter expected weight in grams:");
      return;
    }

    // Small delay allows the user to set the potentiometer in a simulator.
    Serial.println("Set the potentiometer to simulate actual weight.");
    delay(1500);

    int adcValue = analogRead(POT_PIN);  // ESP32 ADC nominal range: 0–4095
    float actualWeight = (adcValue / 4095.0f) * SIMULATED_MAX_GRAMS;

    Serial.print("Expected weight: ");
    Serial.print(expectedWeight, 1);
    Serial.println(" g");
    Serial.print("Simulated actual weight: ");
    Serial.print(actualWeight, 1);
    Serial.println(" g");

    if (actualWeight >= expectedWeight) {
      Serial.println("RESULT: PASS");
      digitalWrite(LED_PIN, HIGH);
      digitalWrite(BUZZER_PIN, LOW);
    } else {
      Serial.println("RESULT: TAMPER ALERT — measured weight is below expected weight.");
      digitalWrite(LED_PIN, LOW);
      digitalWrite(BUZZER_PIN, HIGH);
    }

    decisionMade = true;
    Serial.println("Decision complete. Reset the ESP32 to run another test.");
  }
}
