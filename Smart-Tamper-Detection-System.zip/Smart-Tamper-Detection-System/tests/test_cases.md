# Test Cases

## Manual hardware/simulator tests

| ID | Expected (g) | Simulated actual (g) | Expected result | Purpose |
|---|---:|---:|---|---|
| TC-01 | 500 | 500 | PASS | Exact match |
| TC-02 | 500 | 510 | PASS | Measured value above expected |
| TC-03 | 500 | 499 | TAMPER ALERT | Shortfall of 1 g |
| TC-04 | 500 | 480 | TAMPER ALERT | Shortfall of 20 g |
| TC-05 | 100 | 90 | TAMPER ALERT | Lower measured value |
| TC-06 | 100 | 100 | PASS | Exact match at a different value |
| TC-07 | blank | — | No decision; prompt remains | Empty input |
| TC-08 | `abc` | — | Invalid input message | Non-numeric input |
| TC-09 | 0 or negative | — | Invalid input message | Invalid expected value |

## Acceptance criteria
1. Expected values greater than zero are accepted.
2. A measured value equal to or greater than expected produces PASS.
3. A measured value below expected produces TAMPER ALERT.
4. LED is on for PASS; buzzer is on for TAMPER ALERT.
5. Only one decision is made before the board is reset.

## Notes
The sketch uses an analog potentiometer mapped linearly to 0–1000 g. ADC noise and simulator behavior can cause nearby values to vary. For repeatable tests, use a calibrated test input or add a software test harness for the comparison logic.
